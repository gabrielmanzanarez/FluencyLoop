import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
})
export class Tab1Page implements AfterViewInit {
  private animating: boolean = false;

  constructor() {}

  ngAfterViewInit(): void {
    this.init();
  }

  private init(): void {
    const nextButtons = document.querySelectorAll<HTMLElement>('.next');
    const prevButtons = document.querySelectorAll<HTMLElement>('.previous');

    nextButtons.forEach(btn => {
      btn.addEventListener('click', (e) => this.handleNext(e));
    });

    prevButtons.forEach(btn => {
      btn.addEventListener('click', (e) => this.handlePrevious(e));
    });
  }

  private handleNext(e: Event): void {
    if (this.animating) return;
    this.animating = true;

    const btn = e.target as HTMLElement;
    const current_fs = btn.parentElement as HTMLFieldSetElement;
    const next_fs = current_fs.nextElementSibling as HTMLFieldSetElement;

    if (!current_fs || !next_fs) return;

    // Actualizar progressbar
    const fieldsets = Array.from(document.querySelectorAll('fieldset'));
    const index = fieldsets.indexOf(next_fs);
    const progressbarItems = document.querySelectorAll<HTMLElement>('#progressbar li');
    if (progressbarItems[index]) {
      progressbarItems[index].classList.add('active');
    }

    next_fs.style.display = 'block';

    this.animate(
      (now: number) => {
        const scale = 1 - (1 - now) * 0.2;
        const left = (now * 50) + '%';
        const opacity = 1 - now;

        current_fs.style.transform = `scale(${scale})`;
        current_fs.style.position = 'absolute';
        current_fs.style.opacity = opacity.toString();

        next_fs.style.left = left;
        next_fs.style.opacity = opacity.toString();
      },
      () => {
        current_fs.style.display = 'none';
        this.animating = false;
      }
    );
  }

  private handlePrevious(e: Event): void {
    if (this.animating) return;
    this.animating = true;

    const btn = e.target as HTMLElement;
    const current_fs = btn.parentElement as HTMLFieldSetElement;
    const previous_fs = current_fs.previousElementSibling as HTMLFieldSetElement;

    if (!current_fs || !previous_fs) return;

    // Actualizar progressbar
    const fieldsets = Array.from(document.querySelectorAll('fieldset'));
    const index = fieldsets.indexOf(current_fs);
    const progressbarItems = document.querySelectorAll<HTMLElement>('#progressbar li');
    if (progressbarItems[index]) {
      progressbarItems[index].classList.remove('active');
    }

    previous_fs.style.display = 'block';

    this.animate(
      (now: number) => {
        const scale = 0.8 + (1 - now) * 0.2;
        const left = ((1 - now) * 50) + '%';
        const opacity = 1 - now;

        current_fs.style.left = left;
        current_fs.style.opacity = opacity.toString();

        previous_fs.style.transform = `scale(${scale})`;
        previous_fs.style.opacity = opacity.toString();
      },
      () => {
        current_fs.style.display = 'none';
        this.animating = false;
      }
    );
  }

  // Función matemática de Easing que reemplaza el plugin 'easeInOutBack' de jQuery
  private easeInOutBack(t: number): number {
    const c1 = 1.70158;
    const c2 = c1 * 1.525;
    return t < 0.5
      ? (Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2
      : (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
  }

  // Motor de animación personalizado a 60FPS
  private animate(stepFn: (now: number) => void, completeFn: () => void, duration: number = 800): void {
    const startTime = performance.now();

    const tick = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      let progress = elapsed / duration;
      if (progress > 1) progress = 1;

      const easedProgress = this.easeInOutBack(progress);
      const now = 1 - easedProgress; // Simula cómo jQuery reduce la variable `now` (opacity) de 1 a 0

      stepFn(now);

      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        completeFn();
      }
    };

    requestAnimationFrame(tick);
  }
}